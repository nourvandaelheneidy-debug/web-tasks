# Nourvanda's Creative Web Portfolio

A colorful portfolio collecting Web Development coursework and university assignments.

## Sections
- About
- My Assignments
- Contact

## Assignments
- [Assignment 01 — HTML Basics](assignments/assignment-01/index.html)
- [Assignment 02 — Links & Tables](assignments/assignment-02/index.html)
- [Assignment 03 — HTML Forms](assignments/assignment-03/register.html)

## Built with
HTML · CSS · JavaScript
